# Telium - The game

import random

# Global Variables

num_modules = 17
module = 1
last_module = 0
possible_moves = []
alive = True
won = False
power = 100
fuel = 500
locked = 0
queen = 0
vent_shafts = []
info_panels = []
workers = []

# Procedure declaration

def load_module():
    global module, possible_moves
    possible_moves = get_modules_from(module)
    output_module()

def get_modules_from(module):
    moves = []
    text_file = open("Charles_Darwin\module" + str(module) + ".txt", "r")
    for counter in range(0,4):
        move_read = text_file.readline()
        move_read = int(move_read.strip())
        if move_read != 0:
            moves.append(move_read)
    text_file.close()
    return moves

def output_module():
    global module
    print("")
    print("-----------------------------------------------------------------")
    print()
    print("You are in module", module)
    print()

def output_moves():
    global possible_moves
    print()
    print("From here you can move to modules: | ",end='')
    for move in possible_moves:
        print(move,'| ',end='')
        print()

# Get action from player
def get_action():
     global module, last_module, possible_moves
     valid_action = False
     while valid_action == False:
        # Ask the player what they want to do
        print("What do you want to do next ? (MOVE, SCANNER)")
        # Get the player's response
        action = input(">")
        if action == "MOVE":
            # Move to a new module
            move = int(input("Enter the module to move to: "))
            if move in possible_moves:
                valid_action = True
                last_module = module
                module = move
            else:
                print("The module must be connected to the current module.")
        if action == "SCANNER":
            print("The current power is:",power)
            command = input("Scanner ready. Enter command (LOCK:")
            if command == "LOCK":
                lock()

# Spawn NPCs
def spawn_npcs():
    global num_modules, queen, vent_shafts, greedy_info_panels, workers
    # Create list of modules
    module_set = []
    for counter in range(2, num_modules):
        module_set.append(counter)
    random.shuffle(module_set)
    i = 0
    # Spawn queen
    queen = module_set[i]
    # Spawn vent shafts
    for counter in range(0, 3):
        i += 1
        # Add vent shaft to list
        vent_shafts.append(module_set[i])
    # Spawn info panels
    for counter in range(0, 2):
        i += 1
        # Add info panel to list
        info_panels.append(module_set[i])
    # Spawn workers
    for counter in range(0, 3):
        i += 1
        # Add worker to list
        workers.append(module_set[i])

def check_vent_shafts():
    # Declare global variables
    global num_modules, module, vent_shafts, fuel
    # Check if module is a vent shaft
    if module in vent_shafts:
        print("There is a bank of fuel cells here.")
        print("You load one into your flamethrower.")
        fuel_gained = 50
        # fuel gained is either 20, 30, 40 or 50 at random
        fuel_gained = 10 * random.randint(2,5)
        print("Fuel was",fuel,"now reading:",fuel + fuel_gained)
        # Add fuel gained to fuel
        fuel += fuel_gained
        print("The doors suddenly lock shut.")
        print("What is happening to the station?")
        print("Our only escape is to climb into the ventilation shaft.")
        print("We have no idea where we are going.")
        print("We follow the passages and find ourselves sliding down.")
        last_module = module
        # Move to a random module
        module = random.randint(1, num_modules)
        # Load the new module
        load_module()

def lock():
    global num_modules, power, locked
    new_lock = int(input("Enter a module to lock:"))
    if (new_lock < 0) or (new_lock > num_modules):
        print("Invalid module. Operation failed.")
    elif new_lock == queen:
        print("Operation failed. Unable to lock module.")
    else:
        locked = new_lock
        print("Aliens cannot get into module",locked)
        power_used = 25 + 5*random.randint(0,5)
        power -= power_used


#Main program starts here

while alive and not won:
    load_module()
    check_vent_shafts()
    if won == False and alive == True:
        output_moves()
        get_action()
if won == True:
    print("The queen is trapped and you burn it to death with your flamethrower.")
    print("Game over. You win!")
if alive == False:
    print("The station has run out of power. Unable to sustain life support, you die.")
spawn_npcs()
print("Queen alien is located in module", queen)
print("Ventilation shafts are located in modules", vent_shafts)
print("Information panels are located in modules", info_panels)
print("Worker aliens are located in modules", workers)
